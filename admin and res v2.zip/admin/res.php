
    <table class="table">
      <thead>
        <tr>
          <th>Test Date</th>
          <th>DOB</th>
          <th>ID Number</th>
          <th>Candidate Number</th>

        </tr>
      </thead>
      <tbody>

        <tr>
          <td><?php echo $_POST["test_date"]; ?></td>
          <td><?php echo $_POST["DOB"]; ?></td>
          <td><?php echo $_POST["id_number"]; ?></td>
          <td><?php echo $_POST["cand_number"]; ?></td>
        </tr>
      </tbody>
    </table>